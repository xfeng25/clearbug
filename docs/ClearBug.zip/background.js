// ClearBug service worker: owns the test session (steps + errors) and
// creates bug-report drafts (screenshot + context) when the tester reports a bug.

const MAX_STEPS = 80;
const MAX_ERRORS = 40;
const DRAFT_TTL_MS = 7 * 24 * 60 * 60 * 1000;

// Serialize every read-modify-write of the session so events from several
// tabs never overwrite each other.
let chain = Promise.resolve();
function serial(fn) {
  const p = chain.then(fn);
  chain = p.catch((e) => console.error('[ClearBug]', e));
  return p;
}

async function getSession() {
  const { session } = await chrome.storage.local.get('session');
  return session || null;
}

async function setBadge(active) {
  await chrome.action.setBadgeText({ text: active ? 'REC' : '' });
  if (active) await chrome.action.setBadgeBackgroundColor({ color: '#D93025' });
}

function pushEvent(session, event) {
  session.seq = (session.seq || 0) + 1;
  const ev = { ...event, seq: session.seq, t: Date.now() };

  if (ev.kind === 'error') {
    const last = session.errors[session.errors.length - 1];
    if (last && last.text === ev.text && ev.t - last.t < 2000) return; // duplicate burst
    session.errors.push(ev);
    if (session.errors.length > MAX_ERRORS) session.errors.shift();
    return;
  }

  const last = session.steps[session.steps.length - 1];
  // Typing in the same field twice in a row -> keep only the final value
  if (last && ev.kind === 'input' && last.kind === 'input' && last.field === ev.field) {
    session.steps[session.steps.length - 1] = ev;
    return;
  }
  // Same page logged twice (page load + route event)
  if (last && ev.kind === 'navigate' && last.kind === 'navigate' && last.url === ev.url) return;

  session.steps.push(ev);
  if (session.steps.length > MAX_STEPS) session.steps.shift();
}

// Tabs that belong to the test: the tab the session started in and any tab it
// opens (pop-ups, "open in new tab"). Page errors from other tabs (Notion,
// email, news sites the tester has open) are ignored so they don't show up as
// bug reports, and clicks there are not recorded as steps.
function isTestTab(session, tab) {
  if (!tab) return true;
  if (!Array.isArray(session.tabIds)) return true; // sessions from older versions
  return session.tabIds.includes(tab.id);
}

async function addEvent(event, sender) {
  const session = await getSession();
  if (!session || !session.active) return;
  const tab = sender && sender.tab;
  if (tab && Array.isArray(session.tabIds) && !session.tabIds.length && event.kind !== 'error') {
    session.tabIds.push(tab.id); // started on a chrome:// page: adopt the first tab the tester works in
  }
  if (!isTestTab(session, tab)) return;
  if (sender && sender.tab && !event.url && event.kind !== 'error') event.url = sender.tab.url;
  pushEvent(session, event);
  await chrome.storage.local.set({ session });
}

async function startSession({ tester, module, tab }) {
  const session = {
    active: true,
    id: 's' + Date.now().toString(36),
    startedAt: new Date().toISOString(),
    tester: tester || '',
    module: module || '',
    seq: 0,
    mark: 0,
    steps: [],
    errors: [],
    tabIds: tab && tab.id != null ? [tab.id] : [],
  };
  if (tab) pushEvent(session, { kind: 'navigate', text: `Started on page "${(tab.title || tab.url || '').slice(0, 70)}"`, url: tab.url });

  const { settings = {} } = await chrome.storage.local.get('settings');
  await chrome.storage.local.set({ session, settings: { ...settings, lastTester: tester || '', lastModule: module || '' } });
  await setBadge(true);  await hookOn().catch(() => {});
}

async function stopSession() {
  const session = await getSession();
  if (session) {
    session.active = false;
    session.stoppedAt = new Date().toISOString();
    await chrome.storage.local.set({ session });
  }
  await setBadge(false);  // recorder.js removes the page hook from open test pages.
}

async function clearSteps() {
  const session = await getSession();
  if (!session) return;
  session.steps = [];
  session.errors = [];
  session.mark = session.seq || 0;
  await chrome.storage.local.set({ session });
}

// Called when the tester opens a test case: make sure recording is on and
// start the "since" window for this test case.
async function startCase({ caseId, module, tester, tab }) {
  let session = await getSession();
  if (!session || !session.active) {
    await startSession({ tester, module, tab });
    session = await getSession();
  } else {
    session.mark = session.seq || 0;
    if (tab && tab.id != null) {
      if (!Array.isArray(session.tabIds)) session.tabIds = [];
      if (!session.tabIds.includes(tab.id)) session.tabIds.push(tab.id);
    }
    if (tab) pushEvent(session, { kind: 'navigate', text: `Started test case ${caseId} on "${(tab.title || '').slice(0, 60)}"`, url: tab.url });
  }
  session.caseId = caseId;
  if (tester) session.tester = tester;
  await chrome.storage.local.set({ session });
  await hookOn().catch(() => {});
}

// Chrome allows about 2 captures per second; if a tester clicks Pass quickly,
// wait and try again instead of silently losing the screenshot.
async function captureVisible(windowId, opts) {
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      return await chrome.tabs.captureVisibleTab(windowId, opts);
    } catch (e) {
      if (!/MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND/.test(String(e && e.message))) throw e;
      await new Promise((r) => setTimeout(r, 600));
    }
  }
  throw new Error('Screenshot rate limit');
}

async function captureEvidence(tabId) {
  const tab = await chrome.tabs.get(tabId);
  try {
    return await captureVisible(tab.windowId, { format: 'jpeg', quality: 60 });
  } catch (e) {
    return null;
  }
}

async function createDraft(tabId, extra = {}) {
  const tab = await chrome.tabs.get(tabId);

  let screenshot = null;
  try {
    screenshot = await captureVisible(tab.windowId, { format: 'png' });
  } catch (e) {
    // Chrome blocks captures of chrome:// pages, the Web Store, etc.
    console.warn('[ClearBug] screenshot failed:', e && e.message);
  }

  const session = await getSession();
  let steps = [];
  let errors = [];
  if (session) {
    const since = session.mark || 0;
    steps = session.steps.filter((s) => s.seq > since);
    if (steps.length === 0) steps = session.steps.slice(-10);
    steps = steps.slice(-30);
    errors = session.errors.filter((e) => e.seq > since).slice(-15);
    // The next bug report starts from here
    session.mark = session.seq || 0;
    await chrome.storage.local.set({ session });
  }

  const draftId = 'd' + Date.now().toString(36);
  const draft = {
    draftId,
    createdAt: new Date().toISOString(),
    url: tab.url || '',
    pageTitle: tab.title || '',
    tester: (session && session.tester) || '',
    module: (session && session.module) || '',
    steps,
    errors,
    env: { ua: navigator.userAgent, viewport: tab.width && tab.height ? `${tab.width}×${tab.height}` : '' },
    testCase: extra.testCase || null,
    initialDescription: extra.note || '',
  };
  if (extra.testCase && extra.testCase.module) draft.module = extra.testCase.module;
  if (extra.tester) draft.tester = extra.tester;

  await chrome.storage.local.set({ [`draft:${draftId}`]: draft, [`shot:${draftId}`]: screenshot });
  await chrome.tabs.create({
    url: chrome.runtime.getURL(`report.html?draft=${draftId}`),
    windowId: tab.windowId,
    index: tab.index + 1,
    openerTabId: tab.id,
  });
  return draftId;
}

async function cleanupOldDrafts() {
  const all = await chrome.storage.local.get(null);
  const now = Date.now();
  const remove = [];
  for (const [key, val] of Object.entries(all)) {
    if (key.startsWith('draft:') && val && now - Date.parse(val.createdAt) > DRAFT_TTL_MS) {
      remove.push(key, 'shot:' + key.slice(6));
    }
  }
  if (remove.length) await chrome.storage.local.remove(remove);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const reply = (p) => {
    p.then((r) => sendResponse({ ok: true, result: r }), (e) => sendResponse({ ok: false, error: e.message }));
    return true;
  };
  switch (msg && msg.type) {
    case 'cb:event':
      serial(() => addEvent(msg.event, sender));
      return false;
    case 'cb:start':
      return reply(serial(() => startSession(msg)));
    case 'cb:stop':
      return reply(serial(() => stopSession()));
    case 'cb:clear':
      return reply(serial(() => clearSteps()));
    case 'cb:report':
      return reply(serial(() => createDraft(msg.tabId, msg)));
    case 'cb:start-case':
      return reply(serial(() => startCase(msg)));
    case 'cb:capture':
      return reply(captureEvidence(msg.tabId));
    default:
      return false;
  }
});

chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command !== 'report-bug') return;
  const target = tab || (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (target) serial(() => createDraft(target.id));
});

async function restoreBadge() {
  const session = await getSession();
  await setBadge(!!(session && session.active));
}

// Clicking the toolbar button opens the ClearBug side panel
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

// ---------- website access ----------
// ClearBug asks for website access at first use (optional permission).
// Once granted, the recorder scripts are registered for every page load
// and injected into tabs that are already open.
const SCRIPT_IDS = ['cb-hook', 'cb-recorder'];
const ALL_SITES = { origins: ['<all_urls>'] };

// Only the recorder is registered for page loads; it stays silent unless a test
// session is running. The page hook (which wraps fetch / XHR / console.error to
// catch page errors) is never registered site-wide: it is injected only into
// the tabs being tested, so other sites (Amazon, Notion…) are never touched.
let syncChain = Promise.resolve();
function syncContentScripts() {
  const run = async () => {
    const granted = await chrome.permissions.contains(ALL_SITES);
    const existing = await chrome.scripting.getRegisteredContentScripts({ ids: SCRIPT_IDS }).catch(() => []);
    if (existing.length) await chrome.scripting.unregisterContentScripts({ ids: existing.map((s) => s.id) });
    if (!granted) return false;
    await chrome.scripting.registerContentScripts([
      { id: 'cb-recorder', matches: ['<all_urls>'], js: ['content/recorder.js'], runAt: 'document_start' },
    ]);
    return true;
  };
  const p = syncChain.then(run);
  syncChain = p.catch(() => false);
  return syncChain;
}

const WEB_TABS = { url: ['http://*/*', 'https://*/*', 'file:///*'] };

async function injectRecorder(tabId) {
  try { await chrome.scripting.executeScript({ target: { tabId }, files: ['content/recorder.js'] }); }
  catch (_) { /* chrome:// pages, web store, etc. */ }
}

async function injectHook(tabId) {
  try { await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', files: ['content/page-hook.js'], injectImmediately: true }); }
  catch (_) { /* chrome:// pages, web store, no access, etc. */ }
}

async function testTabIds() {
  const session = await getSession();
  return session && session.active && Array.isArray(session.tabIds) ? session.tabIds : [];
}

async function onAccessGranted() {
  if (!(await syncContentScripts())) return;
  const ids = await testTabIds();
  const tabs = await chrome.tabs.query(WEB_TABS);
  await Promise.all(tabs.map(async (t) => {
    if (ids.includes(t.id)) await injectHook(t.id);
    await injectRecorder(t.id);
  }));
}

// Session started: add the page hook to the tab being tested.
async function hookOn() {
  const ids = await testTabIds();
  await Promise.all(ids.map((id) => injectHook(id)));
}

// A test tab loads a new page: add the hook to it as early as possible.
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status !== 'loading') return;
  testTabIds().then((ids) => { if (ids.includes(tabId)) injectHook(tabId); }).catch(() => {});
});

chrome.permissions.onAdded.addListener(() => { onAccessGranted(); });
chrome.permissions.onRemoved.addListener(() => { syncContentScripts(); });

chrome.runtime.onStartup.addListener(() => { restoreBadge(); cleanupOldDrafts(); syncContentScripts(); });
chrome.runtime.onInstalled.addListener(() => { restoreBadge(); cleanupOldDrafts(); onAccessGranted(); });
